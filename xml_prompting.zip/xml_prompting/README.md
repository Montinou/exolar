# XML Prompt Framework for Claude

A structured framework for AI-assisted feature development using XML prompts. Designed for developers working with Claude Code and Claude API.

## What is This?

This framework provides:
- **Structured prompts** - XML-based prompts for consistent, reliable AI interactions
- **Feature workflow** - Investigation → Phases → Implementation pattern
- **Progress tracking** - Status files that persist context across sessions
- **Reusable templates** - Ready-to-use templates for common scenarios

## Why XML Prompts?

| Benefit | Description |
|---------|-------------|
| **Clarity** | Clear separation of instructions, context, and data |
| **Accuracy** | Reduces misinterpretation by Claude |
| **Parseability** | Easy to extract specific outputs |
| **Consistency** | Same structure across all prompts |

## Folder Structure

```
xml_prompting/
├── README.md                    # This file
├── AI_CONFIGURATION.xml         # Configure Claude to use this framework
│
├── prompts/                     # Active feature prompts
│   ├── README.md                # Workflow documentation
│   └── <feature-slug>/          # One folder per feature
│       ├── status.md            # Progress tracking (ALWAYS updated)
│       ├── investigation/       # Research phase
│       │   ├── prompt.xml       # Investigation prompt
│       │   └── findings.md      # Research output
│       └── phases/              # Implementation phases
│           ├── 01_<name>.xml    # Phase 1 prompt
│           └── 02_<name>.xml    # Phase 2 prompt
│
└── prompt-engineering/          # Templates and guides
    ├── README.md                # Quick reference
    ├── guides/                  # Conceptual documentation
    │   ├── xml-fundamentals.md  # XML syntax and best practices
    │   ├── context-engineering.md # 6-layer context stack
    │   └── claude-4x-guidelines.md # Claude 4.x optimizations
    └── templates/               # Reusable XML templates
        ├── _index.xml           # Template catalog
        ├── general/             # System prompts, few-shot
        ├── reasoning/           # Chain-of-thought, analysis
        ├── code/                # Code generation, review
        ├── agents/              # Context engineering, security
        ├── data/                # Data extraction, synthesis
        └── features/            # Feature development workflow
```

## How It Works

### The Workflow

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Investigation  │ ──► │    Phases       │ ──► │  Implementation │
│  (Research)     │     │  (Planning)     │     │  (Execution)    │
└─────────────────┘     └─────────────────┘     └─────────────────┘
       │                       │                       │
       ▼                       ▼                       ▼
   findings.md            01_*.xml               Code changes
   phases/*.xml           02_*.xml               status.md updated
   status.md              status.md              Commits made
```

1. **Investigation Phase**: Research the codebase, understand requirements, plan phases
2. **Phase Execution**: Run each phase prompt sequentially
3. **Status Tracking**: Update `status.md` after EVERY execution

### Key Rule: Always Update status.md

After executing ANY prompt:
1. Record what was accomplished
2. List files modified/created
3. Document decisions made
4. Note next steps

This ensures context persists across sessions.

## Quick Start

### 1. Create a New Feature

```bash
mkdir -p prompts/<feature-slug>/{investigation,phases}
touch prompts/<feature-slug>/status.md
```

### 2. Create Investigation Prompt

Copy from `prompt-engineering/templates/features/investigation.xml`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<investigation_prompt>
  <feature>
    <name>My Feature</name>
    <folder>prompts/my-feature</folder>
    <phase>investigation</phase>
  </feature>

  <task>
    <objective>Research and plan the implementation</objective>
  </task>

  <investigation_steps>
    <step priority="high">
      <name>Codebase Analysis</name>
      <action>Search for related code patterns</action>
    </step>
    <!-- Add more steps -->
  </investigation_steps>

  <mandatory_final_step priority="critical">
    <action>Update status.md with results</action>
  </mandatory_final_step>
</investigation_prompt>
```

### 3. Run the Prompt

Give the prompt to Claude. Claude will:
- Execute the investigation steps
- Create findings documentation
- Generate phase prompts
- Update status.md

### 4. Execute Phases

Run each phase prompt in sequence:
```
phases/01_setup.xml → phases/02_implement.xml → phases/03_verify.xml
```

## Real Example

See `prompts/db-abstraction-refactor/` for a completed real-world example:
- Investigation that analyzed a 2970-line file
- 4 implementation phases
- Refactored into 14 focused domain files
- Full execution history in status.md

## Claude-Specific Tips

### For Claude 4.x (Opus 4.5, Sonnet 4.5)

1. **Be Literal**: Claude 4.x does exactly what you ask, nothing more
   ```xml
   <!-- Be explicit about what you want -->
   <constraints>
     <rule>Keep solution minimal</rule>
     <rule>Only modify requested files</rule>
   </constraints>
   ```

2. **Avoid "Think"**: When extended thinking is off, use alternatives
   - Use: consider, evaluate, analyze, examine
   - Avoid: think, think about, think through

3. **Prevent Over-Engineering**: Opus 4.5 tends to add extras
   ```xml
   <constraints>
     <rule>No unnecessary abstractions</rule>
     <rule>Don't add features beyond requirements</rule>
   </constraints>
   ```

### Using AI_CONFIGURATION.xml

Add `AI_CONFIGURATION.xml` to your Claude conversation to:
- Configure Claude to understand this framework
- Set mandatory behaviors (status updates, commits)
- Establish workflow rules

## Template Quick Reference

| Template | Use For |
|----------|---------|
| `features/investigation.xml` | Starting a new feature |
| `features/feature-prompt.xml` | Implementation phases |
| `features/iterative.xml` | Refinement cycles |
| `code/code-generation.xml` | Writing new code |
| `code/code-review.xml` | Reviewing code |
| `agents/context-stack.xml` | Building AI agents |
| `reasoning/chain-of-thought.xml` | Complex reasoning |

See `prompt-engineering/templates/_index.xml` for full catalog.

## Best Practices

1. **Update status.md after EVERY execution** - This is non-negotiable
2. **Keep phases standalone** - Each phase should work independently
3. **Document decisions** - Explain WHY, not just what
4. **Use templates** - Don't reinvent the wheel
5. **Commit after each phase** - Format: `feat(<slug>): <phase> - <description>`

## XML Structure Pattern

All prompts follow this structure:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<prompt_type>
  <feature>
    <name>Feature Name</name>
    <folder>prompts/feature-slug</folder>
    <phase>phase-name</phase>
  </feature>

  <task>
    <objective>What to accomplish</objective>
    <constraints>
      <rule>Constraint 1</rule>
      <rule>Constraint 2</rule>
    </constraints>
  </task>

  <steps>
    <step priority="high">
      <name>Step Name</name>
      <action>What to do</action>
      <output>Expected output</output>
    </step>
  </steps>

  <deliverables>
    <deliverable>path/to/file.md</deliverable>
  </deliverables>

  <!-- MANDATORY: Always include these -->
  <mandatory_final_step priority="critical">
    <action>Update status.md</action>
  </mandatory_final_step>

  <mandatory_commit_step priority="critical">
    <commit_format>feat(slug): phase - description</commit_format>
  </mandatory_commit_step>
</prompt_type>
```

## Getting Help

- **XML syntax**: See `prompt-engineering/guides/xml-fundamentals.md`
- **Context engineering**: See `prompt-engineering/guides/context-engineering.md`
- **Claude 4.x specifics**: See `prompt-engineering/guides/claude-4x-guidelines.md`

## License

This framework is provided as-is for educational and practical use.

---
*Last updated: January 2026*
